package gamecore;

public enum ElementInBoard {
    BLACK, WHITE, EMPTY
}